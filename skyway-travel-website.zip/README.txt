SKYWAY TRAVEL & TOURISM — WEBSITE FILE

1. Open index.html in a browser to preview the website.
2. The WhatsApp enquiry form is configured for +971 50 837 2026.
3. To publish, upload index.html to a static hosting provider such as GitHub Pages.
4. Before publishing, verify the WhatsApp number and replace any wording/contact details you want changed.
5. The form opens WhatsApp with a pre-filled message. It does not store enquiries or process payments/bookings automatically.
